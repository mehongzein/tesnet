# 🛰️ Mawari Guardian Node (Testnet - Codespaces)

This repository lets you quickly spin up a **Mawari Guardian Node** on the **Testnet** using GitHub Codespaces.

---

## 🚀 How to Run

1. Open this repository in GitHub.
2. Click **"Code" → "Open with Codespaces" → "New Codespace"**.
3. Wait until Codespace finishes setting up (it takes 2–3 minutes).
4. In the terminal, run the following commands:

   ```bash
   mkdir -p ~/mawari
   docker run --pull always      -v ~/mawari:/app/cache      -e OWNERS_ALLOWLIST=$OWNER_ADDRESS      $MNTESTNET_IMAGE
   ```

5. You should see logs similar to:
   ```
   Starting Guardian Node...
   Connected to Mawari TestNet
   Owner: 0x17160623d16519713116D6e3d62a7c7267F07760
   Node status: Active
   ```

---

## ⚠️ Notes
- Codespaces will **stop** after ~30–60 minutes of inactivity.
- This setup is **only for testing**, not for running a permanent node.
- Data is stored in `~/mawari` within your Codespace container.
